#include "combodelegate.h"
#include<QtGui>
#include<QDebug>
//! [0]
comboDelegate::comboDelegate(QObject *parent)
    : QItemDelegate(parent)
{
}
//! [0]

//! [1]
QWidget *comboDelegate::createEditor(QWidget *parent,
    const QStyleOptionViewItem &/* option */,
    const QModelIndex &/* index */) const
{
    QComboBox *editor = new QComboBox(parent);
    qDebug()<<"create editor";
        editor->addItems(listComBovalue);
    return editor;
}
//! [1]

//! [2]
void comboDelegate::setEditorData(QWidget *editor,
                                    const QModelIndex &index) const
{
    int value = index.model()->data(index, Qt::EditRole).toInt();
    qDebug()<<"set editor data";
    QComboBox *comboBox = static_cast<QComboBox*>(editor);
    int idex= comboBox->findData(value,Qt::UserRole,Qt::MatchExactly);
    comboBox->setCurrentIndex(idex);
}
//! [2]

//! [3]
void comboDelegate::setModelData(QWidget *editor, QAbstractItemModel *model,
                                   const QModelIndex &index) const
{
    qDebug()<<"set model";
    QComboBox *comBoBox = static_cast<QComboBox*>(editor);
    QVariant value =  comBoBox->itemData(comBoBox->currentIndex(),Qt::UserRole);
    model->setData(index, value, Qt::DisplayRole);
   // MainDbCommonViewModel  *modelMessage=dynamic_cast<MainDbCommonViewModel*> model;
}
//! [3]

//! [4]
void comboDelegate::updateEditorGeometry(QWidget *editor,
    const QStyleOptionViewItem &option, const QModelIndex &/* index */) const
{
    qDebug()<<"set geo";
    editor->setGeometry(option.rect);
}
//! [4]
