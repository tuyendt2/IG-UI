#include "maindbeditor.h"
#include <QMessageBox>
#include <QCloseEvent>
#include <QDebug>
#include<combodelegate.h>

#include<QTreeWidgetItem>
#include <QSplitter>
MainDbEditor::MainDbEditor(QWidget *parent , QString  path ):
    QMainWindow(parent),
    m_mainDbManager(NULL),
    m_MsgEditorWidget(NULL)
{
    setupUi(this);
    QSplitter * splitter = new QSplitter(Qt::Horizontal,this);
    splitter->addWidget(m_treeWidget);
    splitter->addWidget(m_stackedWidget);
    QGridLayout * gridLayout = new QGridLayout;
    gridLayout->addWidget(splitter);
    centralWidget()->setLayout(gridLayout);
    m_stackedWidget->removeWidget(m_pageCom);
    m_stackedWidget->removeWidget(m_pageSignals);
    m_stackedWidget->removeWidget(m_pageMsgs);
    m_stackedWidget->addWidget(m_MsgsTableWidget);
    m_stackedWidget->addWidget(m_SignsTableWidget);
    m_stackedWidget->addWidget(m_ComTableWidget);

    m_mainDbManager = new MainDbManager();
    m_mainDbManager->loadDbFile(path);

    m_treeViewModel = new MainDbTreeViewModel(m_mainDbManager,this);
    m_treeWidget->setModel(m_treeViewModel);

    m_tblMsgModel = new MainDbTableMsgsModel(m_mainDbManager,this);
    m_MsgsTableWidget->setModel(m_tblMsgModel);
    comboDelegate *messagetableDelegate= new comboDelegate;
    messagetableDelegate->listComBovalue=QString("CAN 1;CAN2").split(";");
    m_MsgsTableWidget->setItemDelegate(messagetableDelegate);

    m_tblSignModel = new MainDbTableSignsModel(m_mainDbManager,this);
    m_SignsTableWidget->setModel(m_tblSignModel);
    m_SignsTableWidget->setItemDelegate(messagetableDelegate);
    m_MsgsTableWidget->setShowGrid(false);
    m_SignsTableWidget->setShowGrid(false);
    m_ComTableWidget->setShowGrid(false);

    m_MsgsTableWidget->verticalHeader()->hide();
    m_SignsTableWidget->verticalHeader()->hide();
    m_ComTableWidget->verticalHeader()->hide();

    m_MsgsTableWidget->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    m_SignsTableWidget->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    m_ComTableWidget->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);

    m_MsgsTableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    m_SignsTableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    m_ComTableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    m_treeWidget->setContextMenuPolicy(Qt::CustomContextMenu);

    connect(m_treeWidget,SIGNAL(clicked(QModelIndex)),this, SLOT(slotOneClickTree(QModelIndex)));
    connect(m_treeWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickTree(QModelIndex)));
    connect(m_treeWidget,SIGNAL(customContextMenuRequested(QPoint)),this, SLOT(slotContextMenuTreeWidget(QPoint)));

    connect(m_MsgsTableWidget,SIGNAL(clicked(QModelIndex)),this, SLOT(slotOneClickMsgsTab(QModelIndex)));
    connect(m_MsgsTableWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickMsgsTab(QModelIndex)));
    connect(m_MsgsTableWidget,SIGNAL(customContextMenuRequested(QPoint)),this, SLOT(slotContextMenuMsgTable(QPoint)));

    connect(m_SignsTableWidget,SIGNAL(customContextMenuRequested(QPoint)),this, SLOT(slotContextMenuSignsTable(QPoint)));
    connect(m_SignsTableWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickSignsTab(QModelIndex)));


    connect(m_ComTableWidget,SIGNAL(customContextMenuRequested(QPoint)),this, SLOT(slotContextMenuCombTable(QPoint)));
    connect(m_ComTableWidget,SIGNAL(doubleClicked(QModelIndex)),this, SLOT(slotDoubleClickCombTab(QModelIndex)));
}

MainDbEditor::~MainDbEditor()
{
    /*TODO: remove db list*/
    if(m_mainDbManager) delete m_mainDbManager;
    if(m_MsgEditorWidget) delete m_MsgEditorWidget;
}

void MainDbEditor::slotOneClickTree(QModelIndex index){

    switch (m_treeViewModel->getItem(index)->getType()) {
    case E_DbItemType_Header:
        if(m_treeViewModel->getItem(index)->data(0) == QString("Messages")){
            m_MsgsTableWidget->setVisible(true);
            m_SignsTableWidget->setVisible(false);
            m_ComTableWidget->setVisible(false);
        }else if(m_treeViewModel->getItem(index)->data(0) == QString("Signals")){
            m_MsgsTableWidget->setVisible(false);
            m_SignsTableWidget->setVisible(true);
            m_ComTableWidget->setVisible(false);
        }
        break;
    case E_DbItemType_Message:
    case E_DbItemType_Signal:
    case E_DbItemType_SignalInMessage:
        m_MsgsTableWidget->setVisible(false);
        m_SignsTableWidget->setVisible(false);
        m_ComTableWidget->setVisible(true);
        break;
    default:
        break;
    }
    m_MsgsTableWidget->resize(m_stackedWidget->size());
    m_SignsTableWidget->resize(m_stackedWidget->size());
    m_ComTableWidget->resize(m_stackedWidget->size());

}

void MainDbEditor::slotDoubleClickTree(QModelIndex index){
    switch (m_treeViewModel->getItem(index)->getType()) {
    case E_DbItemType_Header:
    {
        //TODO: collapse/expand
    }
        break;
    case E_DbItemType_Message:
    {
        //TODO: Open editor message
    }
        break;
    case E_DbItemType_Signal:
    {
        //TODO: Open editor signal
    }
        break;
    case E_DbItemType_SignalInMessage:
    {
        //TODO: Open editor signal in message
    }
        break;
    default:
        break;
    }

}

void MainDbEditor::slotOneClickMsgsTab(QModelIndex index)
{
    //    qDebug() << index.column() << "x" << index.row();
}


void  MainDbEditor::slotContextMenuMsgTable(QPoint  point)
{
    QMenu *rightClickMenu = new QMenu(this);

    QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit"),this);
    //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenMessageEditor()));

    QAction *actionRemove = new QAction(QIcon(":icons/remove.png"),QString("Remove"),this);
    //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveMessage()));

    rightClickMenu->addAction(actionEdit);
    rightClickMenu->addSeparator();
    rightClickMenu->addAction(actionRemove);

    QPoint globalPos = m_MsgsTableWidget->mapToGlobal(point);
    rightClickMenu->popup(globalPos);
}

void MainDbEditor::slotDoubleClickMsgsTab(QModelIndex index)
{

}

void MainDbEditor::slotOneClickSignsTab(QModelIndex index)
{

}

void MainDbEditor::slotDoubleClickSignsTab(QModelIndex index)
{

}

void MainDbEditor::slotOneClickCombTab(QModelIndex index)
{

}

void MainDbEditor::slotDoubleClickCombTab(QModelIndex index)
{

}

void  MainDbEditor::slotContextMenuSignsTable(QPoint  point)
{
    QMenu *rightClickMenu = new QMenu(this);

    QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit"),this);
    //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalEditor()));

    QAction *actionRemove = new QAction(QIcon(":icons/remove.png"),QString("Remove"),this);
    //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignal()));

    rightClickMenu->addAction(actionEdit);
    rightClickMenu->addSeparator();
    rightClickMenu->addAction(actionRemove);

    QPoint globalPos = m_MsgsTableWidget->mapToGlobal(point);

    rightClickMenu->popup(globalPos);
}

void  MainDbEditor::slotContextMenuCombTable(QPoint  point)
{

    QMenu *rightClickMenu = new QMenu(this);


    QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit"),this);
    //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalInMsgEditor()));

    QAction *actionRemove = new QAction(QIcon(":icons/remove.png"),QString("Remove"),this);
    //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

    rightClickMenu->addAction(actionEdit);
    rightClickMenu->addSeparator();
    rightClickMenu->addAction(actionRemove);

    QPoint globalPos = m_MsgsTableWidget->mapToGlobal(point);

    rightClickMenu->popup(globalPos);

}

void  MainDbEditor::slotContextMenuTreeWidget(QPoint  point)
{
    QMenu *rightClickMenu = new QMenu(this);

    switch (m_treeViewModel->getItem(m_treeWidget->selectionModel()->currentIndex())->getType()) {
    case E_DbItemType_Header:
    {
        if(m_treeViewModel->getItem(m_treeWidget->selectionModel()->currentIndex())->data(0) == QString("Messages")){
            QAction *actionNew = new QAction(QIcon(":icons/new.png"),QString("New message"),this);
            //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalInMsgEditor()));

            QAction *actionPaste = new QAction(QIcon(":icons/paste.png"),QString("Paste"),this);
            //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
            actionPaste->setEnabled(false);
            rightClickMenu->addAction(actionNew);
            rightClickMenu->addSeparator();
            rightClickMenu->addAction(actionPaste);
//            QPoint globalPos = m_treeWidget->mapToGlobal(point);
//            rightClickMenu->popup(globalPos);
            rightClickMenu->popup(point);
        }else if(m_treeViewModel->getItem(m_treeWidget->selectionModel()->currentIndex())->data(0) == QString("Signals")){
            QAction *actionNew = new QAction(QIcon(":icons/new.png"),QString("New signal"),this);
            //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalInMsgEditor()));

            QAction *actionPaste = new QAction(QIcon(":icons/paste.png"),QString("Paste"),this);
            //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
            actionPaste->setEnabled(false);
            rightClickMenu->addAction(actionNew);
            rightClickMenu->addSeparator();
            rightClickMenu->addAction(actionPaste);
            QPoint globalPos = m_treeWidget->mapToGlobal(point);
            rightClickMenu->popup(globalPos);

        }
    }
        break;
    case E_DbItemType_Message:
    {
        QAction *actionNew = new QAction(QIcon(":icons/new.png"),QString("New message"),this);
        //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalInMsgEditor()));

        QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit message"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionCopy= new QAction(QIcon(":icons/copy.png"),QString("Copy"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionPaste = new QAction(QIcon(":icons/paste.png"),QString("Paste"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
        actionPaste->setEnabled(false);

        QAction *actionDelete = new QAction(QIcon(":icons/remove.png"),QString("Delete"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        rightClickMenu->addAction(actionNew);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionEdit);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionCopy);
        rightClickMenu->addAction(actionPaste);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionDelete);

        QPoint globalPos = m_treeWidget->mapToGlobal(point);
        rightClickMenu->popup(globalPos);
    }
        break;

    case E_DbItemType_Signal:
    {
        QAction *actionNew = new QAction(QIcon(":icons/new.png"),QString("New signal"),this);
        //    connect(actionEdit, SIGNAL(triggered()),  this, SLOT(slotOpenSignalInMsgEditor()));

        QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit signal"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionCopy= new QAction(QIcon(":icons/copy.png"),QString("Copy"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionPaste = new QAction(QIcon(":icons/paste.png"),QString("Paste"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));
        actionPaste->setEnabled(false);

        QAction *actionDelete = new QAction(QIcon(":icons/remove.png"),QString("Delete"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        rightClickMenu->addAction(actionNew);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionEdit);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionCopy);
        rightClickMenu->addAction(actionPaste);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionDelete);

        QPoint globalPos = m_treeWidget->mapToGlobal(point);
        rightClickMenu->popup(globalPos);
    }
        break;

    case E_DbItemType_SignalInMessage:
    {
        QAction *actionEdit = new QAction(QIcon(":icons/edit.png"),QString("Edit signal"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionCopy= new QAction(QIcon(":icons/copy.png"),QString("Copy"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        QAction *actionDelete = new QAction(QIcon(":icons/remove.png"),QString("Remove"),this);
        //    connect(actionRemove, SIGNAL(triggered()),  this, SLOT(slotRemoveSignalInMsg()));

        rightClickMenu->addAction(actionEdit);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionCopy);
        rightClickMenu->addSeparator();

        rightClickMenu->addAction(actionDelete);

        QPoint globalPos = m_treeWidget->mapToGlobal(point);
        rightClickMenu->popup(globalPos);
    }
        break;

    default:
        break;
    }

}

void MainDbEditor::closeEvent(QCloseEvent *event)
{
    //TODO: need to check change before asking
    QMessageBox::StandardButton resBtn = QMessageBox::question( this, "CANdb Editor",
                                                                tr("Do you want to save changes?\n"),
                                                                QMessageBox::Cancel | QMessageBox::No | QMessageBox::Yes,
                                                                QMessageBox::Cancel);
    if (resBtn == QMessageBox::Yes) {
        //TODO: Saving to database file
        event->accept();
    } else if (resBtn == QMessageBox::Cancel) {
        event->ignore();
    }else{
        //TODO: do not saving

        event->accept();
    }
}

void MainDbEditor::slotLoadDb(QString & path)
{
    /*TODO: remove db list*/
}

void MainDbEditor::slotSaveDb(QString & path)
{

}

void MainDbEditor::slotOpenMessageEditor()
{

}

void MainDbEditor::slotOpenSignalEditor()
{

}


MainDbManager::MainDbManager()
{

}

MainDbManager::~MainDbManager()
{

}

bool MainDbManager::slotAddMessage(CANMessage & message)
{

}

bool MainDbManager::slotAddSignal(CANSignal & signal)
{

}

bool MainDbManager::slotAddSignal2Message(CANSignal & signal)
{

}

QVector<CANSignalInMessage> MainDbManager::getSignalsInMessage(QString & messageName)
{
    QVector<CANSignalInMessage> ret;
    ret.empty();
    CANMessage * item;
    for(int i = 0; i< m_CANMessages.size();i++)
    {
        item = m_CANMessages.at(i);
        if(item && item->m_Name == messageName){
            ret = item->m_Signals;
        }
    }
    return ret;
}

QVector<CANMessagesOfSignal> MainDbManager::getMessagesOfSignal(int index)
{
    QVector<CANMessagesOfSignal> ret;
    CANMessagesOfSignal newItem;
    ret.empty();
    if(index>= m_CANSignals.size()){
        return ret;
    }
    CANSignal * signal = m_CANSignals.at(index);
    CANMessage * item;

    for(int i = 0; i< m_CANMessages.size();i++)
    {
        item = m_CANMessages.at(i);
        for (int j; j<item->m_Signals.size();j++){
            if(item->m_Signals.at(j).m_Signal == signal)
            {
                newItem.m_msgName = item->m_Name;
                newItem.m_StartBit = item->m_Signals.at(j).m_StartBit;
                ret.append(newItem);
            }
        }
    }
    return ret;
}
bool compareSignal(CANSignal *newSig,CANSignal *oldSig){
    if(newSig->m_Name.compare(oldSig->m_Name)) return false;
    if(newSig->m_ByteOrder!=oldSig->m_ByteOrder) return false;
    //if(newSig->m_Factor!=oldSig->m_Factor) return false;
    if(newSig->m_Length!=oldSig->m_Length) return false;
    //if(newSig->m_Offset!=oldSig->m_Offset) return false;
    if(newSig->m_ValueType!=oldSig->m_ValueType) return false;
    return true;
}

void MainDbManager::loadDbFile(QString & path)
{
    if(path.isEmpty()) return;
    m_CANMessages.clear();
    m_CANSignals.clear();
    CANMessage * newMsg=NULL;
    CANSignal * newSign=NULL;
    QFile file(path);
    file.open(QIODevice::ReadOnly);
    QString string = file.readAll();
    QStringList lines = string.split(QString("\n"),QString::SkipEmptyParts);
    foreach (QString line, lines) {
        QStringList lineItems =  line.split(QRegularExpression(":| |@|\\||\\(|\\)|\\[|\\]|,|\\+"),QString::SkipEmptyParts);
        /*SG_ PWM_CVVAL : 48|16@1+ (6.103515625E-005,0) [0|1] ""  NODE1
      -->"SG_", "PWM_CVVAL", "48", "16", "1+", "6.103515625E-005", "0", "0", "1", """", "NODE1"
          0            1       2     3    4          5             6    7    8     9     10
          0: SG_
          1: signal name
          2: start bit
          3: length in bit
          4: format intel/motorola
          5: factor
          6: offset
          7: min
          8: max
        */
        if(lineItems.size()>=10 && lineItems.at(0) == QString("SG_")){
            CANSignalInMessage newSignalInMsg;
            newSign = new CANSignal;
            newSign->m_Name = lineItems.at(1);
            newSignalInMsg.m_StartBit = (unsigned char)lineItems.at(2).toInt();
            newSign->m_Length = (unsigned char)lineItems.at(3).toInt();
            if(lineItems.at(4)[lineItems.at(4).length()-1] == '+'){
                newSign->m_ValueType = E_CANSignalSign_UnSigned;
            }else{
                newSign->m_ValueType = E_CANSignalSign_Signed;
            }
            int sz = lineItems.at(4).length()-1;
            QString tmp(lineItems.at(4));
            tmp.resize(sz);
            newSign->m_ByteOrder = (E_CANByteOrder)(tmp.toInt());
            newSign->m_Factor.dValue = lineItems.at(5).toDouble();
            newSign->m_Offset.dValue = lineItems.at(6).toDouble();
            newSign->m_Min.dValue = lineItems.at(7).toDouble();
            newSign->m_Max.dValue = lineItems.at(8).toDouble();
//            newSign->m_ = lineItems.at(8).toDouble();
            newSign->m_InitValue.dValue = 0;
            if(m_CANSignals.isEmpty()){
                m_CANSignals.append(newSign);
            }else{
                for(int i=0;i<m_CANSignals.size();i++){
                    if(compareSignal(newSign,m_CANSignals.at(i))) break;
                    if(i==(m_CANSignals.size()-1)){
                        m_CANSignals.append(newSign);
                    }
                }
            }
            newSignalInMsg.m_Signal = newSign;
            newMsg->m_Signals.append(newSignalInMsg);
        }else {
            QStringList lineItems =  line.split(QRegularExpression(":| |@|\\||\\(|\\)|\\[|\\]|,"),QString::SkipEmptyParts);
            if(lineItems.size()>=4 && lineItems.at(0) == QString("BO_")){
                qDebug()<<lineItems.size() << lineItems;
                newMsg = new CANMessage;
                newMsg->m_ID = lineItems.at(1).toUInt();
//                int sz = lineItems.at(2).size();
                newMsg->m_Name = lineItems.at(2);
//                newMsg->m_Name.resize(sz-1);
                newMsg->m_Length  = lineItems.at(3).toInt();
                newMsg->m_IdType  = (newMsg->m_ID & 0x80000000) ? E_CANMsgIDType_Extended: E_CANMsgIDType_Standard;
                newMsg->m_Signals.clear();
                m_CANMessages.append(newMsg);
            }
        }
    }
    file.close();
}

MainDbCommonViewModel::MainDbCommonViewModel(MainDbManager * dbMng,QObject *parent)
    : QAbstractItemModel(parent),
      m_dbManager(dbMng),
      rootItem(NULL)
{
    //    QVector<QVariant> rootData;
    //    rootData << "";
    //    rootItem = new MainDbCommonItem(rootData, E_DbItemType_Header);
    //    setupModelData(rootItem);
}

MainDbCommonViewModel::~MainDbCommonViewModel()
{
    delete rootItem;
}

int MainDbCommonViewModel::columnCount(const QModelIndex & /* parent */) const
{
    return rootItem->columnCount();
}


QModelIndex MainDbCommonViewModel::index(int row, int column, const QModelIndex &parent) const
{
    if (parent.isValid() && parent.column() != 0)
        return QModelIndex();
    MainDbCommonItem *parentItem = getItem(parent);

    MainDbCommonItem *childItem = parentItem->child(row);
    if (childItem)
        return createIndex(row, column, childItem);
    else
        return QModelIndex();
}

bool MainDbCommonViewModel::insertColumns(int position, int columns, const QModelIndex &parent)
{
    bool success = true;
    beginInsertColumns(parent, position, position + columns - 1);
    success = rootItem->insertColumns(position, columns);
    endInsertColumns();
    return success;
}

bool MainDbCommonViewModel::insertRows(int position, int rows, const QModelIndex &parent)
{
    bool success = true;
    MainDbCommonItem *parentItem = getItem(parent);
    beginInsertRows(parent, position, position + rows - 1);
    success = parentItem->insertChildren(position, rows, rootItem->columnCount(),E_DbItemType_Header);
    endInsertRows();
    return success;
}

QModelIndex MainDbCommonViewModel::parent(const QModelIndex &index) const
{
    if (!index.isValid())
        return QModelIndex();
    MainDbCommonItem *childItem = getItem(index);
    MainDbCommonItem *parentItem = childItem->parent();

    if (parentItem == rootItem)
        return QModelIndex();
    return createIndex(parentItem->childNumber(), 0, parentItem);
}

bool MainDbCommonViewModel::removeColumns(int position, int columns, const QModelIndex &parent)
{
    bool success = true;
    beginRemoveColumns(parent, position, position + columns - 1);
    success = rootItem->removeColumns(position, columns);
    endRemoveColumns();
    if (rootItem->columnCount() == 0)
        removeRows(0, rowCount());
    return success;
}

bool MainDbCommonViewModel::removeRows(int position, int rows, const QModelIndex &parent)
{
    bool success = true;
    MainDbCommonItem *parentItem = getItem(parent);
    beginRemoveRows(parent, position, position + rows - 1);
    success = parentItem->removeChildren(position, rows);
    endRemoveRows();
    return success;
}

int MainDbCommonViewModel::rowCount(const QModelIndex &parent) const
{
    MainDbCommonItem *parentItem = getItem(parent);
    return parentItem->childCount();
}

MainDbCommonItem *MainDbCommonViewModel::getItem(const QModelIndex &index) const
{
    if (index.isValid()) {
        MainDbCommonItem *item = static_cast<MainDbCommonItem*>(index.internalPointer());
        if (item)
            return item;
    }
    return rootItem;
}

//MainDbTreeViewModel method define area

QVariant MainDbTreeViewModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();

    if (role != Qt::DisplayRole && role != Qt::DecorationRole && role != Qt::ForegroundRole)
        return QVariant();
    if(role == Qt::DisplayRole){
        MainDbCommonItem *item = getItem(index);
        if(item->getType() == E_DbItemType_Message){
            QString string;
//            qDebug()<< item->data(index.column());
            string.append(item->data(index.column()).toString());
            string.append("\t(0x");
            string.append(QString::number(item->data(index.column()+1).toInt() & (~0x80000000),16));
            string.append(")");
            return string;
        }
        return item->data(index.column());
    }else if(role == Qt::DecorationRole){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType()) {
        case E_DbItemType_Message:
        {
            QPixmap px(":/icons/message.png");
            return px.scaled(14,14);
        }
            break;
        case E_DbItemType_Signal:
        case E_DbItemType_SignalInMessage:
        {

            QPixmap px(":/icons/signal.png");
            return px.scaled(14,14);
        }
            break;
        default:
            break;
        }
    }else if(role == Qt::ForegroundRole){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType()) {
        case E_DbItemType_Header:
        {
            return QVariant( QColor( Qt::darkRed ) );
        }
            break;
        }
    }
}

bool MainDbTreeViewModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool result = true;
    if (role != Qt::EditRole)
        return false;
    MainDbCommonItem *item = getItem(index);
    result = item->setData(index.column(), value);
    if (result)
        emit dataChanged(index, index);
    return result;
}

bool MainDbTreeViewModel::setHeaderData(int section, Qt::Orientation orientation,
                                        const QVariant &value, int role)
{
    if (role != Qt::EditRole || orientation != Qt::Horizontal)
        return false;
    bool result = rootItem->setData(section, value);
    if (result)
        emit headerDataChanged(orientation, section, section);
    return result;
}

Qt::ItemFlags MainDbTreeViewModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return 0;

    return QAbstractItemModel::flags(index);
}


QVariant MainDbTreeViewModel::headerData(int section, Qt::Orientation orientation,
                                         int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);
    return QVariant();
}

void MainDbTreeViewModel::setupModelData(MainDbCommonItem *parent)
{
    QVector <QVariant> data;
    data<< "Messages";
    parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Header);
    parent->child(parent->childCount() - 1)->setData(0, data[0]);

    data.clear();
    data<< "Signals";
    parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Header);
    parent->child(parent->childCount() - 1)->setData(0, data[0]);
    QModelIndex index;
    index = this->index(0,0);
    insertRows(0,m_dbManager->getMessagesList().size(),index);
    int cnt=0;
    foreach (CANMessage * msg, m_dbManager->getMessagesList()) {
        if(msg){
            index = index.child(cnt,0);
            getItem(index)->setData(0,QVariant(msg->m_Name));
            getItem(index)->insertColumns(1,1);
            getItem(index)->setData(1,QVariant(msg->m_ID & (~0x80000000)));
            getItem(index)->setType(E_DbItemType_Message);
            insertRows(0,msg->m_Signals.size(),index);
            int cnt2=0;
            foreach (CANSignalInMessage sgnInMsg, msg->m_Signals) {
                index = index.child(cnt2,0);
                getItem(index)->setData(0,sgnInMsg.m_Signal->m_Name);
                getItem(index)->setType(E_DbItemType_SignalInMessage);
                index = index.parent();
                cnt2++;
            }
            index = index.parent();
        }
        cnt++;
    }

    index = this->index(1,0);
    insertRows(0,m_dbManager->getSignalsList().size(),index);
    cnt=0;
    foreach (CANSignal * sgn, m_dbManager->getSignalsList()) {
        if(sgn){
            index = index.child(cnt,0);
            getItem(index)->setData(0,sgn->m_Name);
            getItem(index)->setType(E_DbItemType_Signal);
            index = index.parent();
        }
        cnt++;
    }
}

//MainDbTableMsgsModel method define  area

MainDbTableMsgsModel::MainDbTableMsgsModel(MainDbManager * dbMng, QObject *parent ):
    MainDbCommonViewModel(dbMng,parent)
{
    QVector<QVariant> rootData;
    rootData <<  "Name" << "ID" << "ID-format" << "DLC [Byte]" << "Comment";
    rootItem = new MainDbCommonItem(rootData, E_DbItemType_Header);
    setupModelData(rootItem);
}

QVariant MainDbTableMsgsModel::data(const QModelIndex &index, int role) const
{
    //    qDebug()<< __FUNCTION__ << __LINE__;
    if (!index.isValid())
        return QVariant();

    if (role != Qt::DisplayRole && role != Qt::EditRole && role != Qt::DecorationRole &&  role != Qt::BackgroundColorRole && role !=Qt::TextAlignmentRole)
        return QVariant();
    if(role == Qt::DisplayRole || role == Qt::EditRole)
    {
        MainDbCommonItem *item = getItem(index);
        if(index.column() == 1){
            //This is message ID column
            QString tmp("0x");
            tmp.append(QString::number(item->data(index.column()).toUInt()& (~0x80000000),16));
            return tmp;
        }
        return item->data(index.column());
    }else if(role == Qt::DecorationRole  && index.column() == 0){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType()) {
        case E_DbItemType_Message:
        {
            QPixmap px(":/icons/message.png");
            return px.scaled(16,16);
        }
            break;
        case E_DbItemType_Signal:
        case E_DbItemType_SignalInMessage:
        {
            QPixmap px(":/icons/signal.png");
            return px.scaled(16,16);
        }
            break;
        default:
            break;
        }
    }else if(role == Qt::BackgroundColorRole){
        if(index.row()%2 == 0){
            return QVariant( QColor( 215, 227, 229 ) );
        }
    }else if (role ==Qt::TextAlignmentRole)   {

    }
    return QVariant();
}

bool MainDbTableMsgsModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    qDebug()<<"message set model";
    bool result = true;
    if (role != Qt::EditRole)
        return false;
    MainDbCommonItem *item = getItem(index);
    result = item->setData(index.column(), value);
    if (result)
        emit dataChanged(index, index);
    return result;
}
bool MainDbTableMsgsModel::setHeaderData(int section, Qt::Orientation orientation,
                                         const QVariant &value, int role)
{
    if (role != Qt::EditRole || orientation != Qt::Horizontal)
        return false;

    bool result = rootItem->setData(section, value);
    if (result)
        emit headerDataChanged(orientation, section, section);
    return result;
}

Qt::ItemFlags MainDbTableMsgsModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return 0;
    return Qt::ItemIsEditable | QAbstractItemModel::flags(index);
}

QVariant MainDbTableMsgsModel::headerData(int section, Qt::Orientation orientation,
                                          int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);
    return QVariant();
}

void MainDbTableMsgsModel::setupModelData(MainDbCommonItem *parent)
{
    QVector <QVariant> data;
    int cnt=0,idx=0;
    foreach (CANMessage * msg, m_dbManager->getMessagesList()) {
        if(msg){
            idx=0;
            parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Message);
            data << msg->m_Name;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << msg->m_ID;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << ((msg->m_IdType == E_CANMsgIDType_Extended) ? QString("Extended") :QString("Standard"));
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << msg->m_Length;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data.clear();
        }
        cnt++;
    }
}

//MainDbTableSignsModel method define area

MainDbTableSignsModel::MainDbTableSignsModel(MainDbManager * dbMng, QObject *parent ):
    MainDbCommonViewModel(dbMng,parent){
    QVector<QVariant> rootData;
    rootData <<  "Name" << "Length [Bit]" << "Byte Order" << "Value Type" << "Initial Value" << "Factor"<< "Offset"<< "Minimum" << "Maximum" << "Comment";
    rootItem = new MainDbCommonItem(rootData, E_DbItemType_Header);
    setupModelData(rootItem);
}

QVariant MainDbTableSignsModel::data(const QModelIndex &index, int role) const
{
    //    qDebug()<< __FUNCTION__ << __LINE__;
    if (!index.isValid())
        return QVariant();

    if (role != Qt::DisplayRole && role != Qt::EditRole && role != Qt::DecorationRole &&  role != Qt::BackgroundColorRole && role !=Qt::TextAlignmentRole)
        return QVariant();
    if(role == Qt::DisplayRole || role == Qt::EditRole){
        MainDbCommonItem *item = getItem(index);
        return item->data(index.column());
    }else if(role == Qt::DecorationRole && index.column() == 0){
        MainDbCommonItem *item = getItem(index);
        switch (item->getType() ) {
        case E_DbItemType_Message:
        {
            QPixmap px(":/icons/message.png");
            return px.scaled(16,16);
        }
            break;
        case E_DbItemType_Signal:
        case E_DbItemType_SignalInMessage:
        {
            QPixmap px(":/icons/signal.png");
            return px.scaled(16,16);
        }
            break;
        default:
            break;
        }
    }else if(role == Qt::BackgroundColorRole){
        if(index.row()%2 == 0){
            return QVariant( QColor( 215, 227, 229 ) );
        }
    }
    return QVariant();
}

bool MainDbTableSignsModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool result = true;
    if (role != Qt::EditRole)
        return false;
    MainDbCommonItem *item = getItem(index);
    result = item->setData(index.column(), value);
    if (result)
        emit dataChanged(index, index);
    return result;
}
bool MainDbTableSignsModel::setHeaderData(int section, Qt::Orientation orientation,
                                          const QVariant &value, int role)
{
    if (role != Qt::EditRole || orientation != Qt::Horizontal)
        return false;

    bool result = rootItem->setData(section, value);
    if (result)
        emit headerDataChanged(orientation, section, section);
    return result;
}

Qt::ItemFlags MainDbTableSignsModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return 0;
    return Qt::ItemIsEditable | QAbstractItemModel::flags(index);
}

QVariant MainDbTableSignsModel::headerData(int section, Qt::Orientation orientation,
                                           int role) const
{
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
        return rootItem->data(section);
    return QVariant();
}

void MainDbTableSignsModel::setupModelData(MainDbCommonItem *parent)
{
    QVector <QVariant> data;
    int cnt=0, idx = 0;
    foreach (CANSignal * sgn, m_dbManager->getSignalsList()) {
        if(sgn){
            //"Name" << "Length [Bit]" << "Byte Order" << "Value Type" << "Initial Value" << "Factor"<< "Offset"<< "Minimum" << "Maximum" ;
            idx = 0;
            parent->insertChildren(parent->childCount(), 1, rootItem->columnCount(),E_DbItemType_Signal);
            data << sgn->m_Name;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << sgn->m_Length;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << (sgn->m_ByteOrder == E_CANByteOrder_Intel ? "Intel": "Motorola");
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data << (sgn->m_ValueType == E_CANSignalSign_Signed ? "Signed" : "Unsigned");
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_InitValue.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Factor.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Offset.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Min.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);
            data <<  sgn->m_Max.dValue;
            parent->child(parent->childCount() - 1)->setData(idx++, data[idx]);

//            switch(sgn->m_ValueType){
//            case E_CANSignalSign_Signed:
//                data << sgn->m_Factor.lValue;
//                data << sgn->m_Offset.lValue;
//                data << sgn->m_Min.lValue;
//                data << sgn->m_Max.lValue;
//                break;
//            case E_CANSignalSign_UnSigned:
//                data << sgn->m_Factor.uValue;
//                data << sgn->m_Offset.uValue;
//                data << sgn->m_Min.uValue;
//                data << sgn->m_Max.uValue;
//                break;

//            case E_CANSignalSign_Double:
//                data << sgn->m_Factor.dValue;
//                data << sgn->m_Offset.dValue;
//                data << sgn->m_Min.dValue;
//                data << sgn->m_Max.dValue;
//                break;

//            case E_CANSignalSign_Float:
//                data << sgn->m_Factor.fValue;
//                data << sgn->m_Offset.fValue;
//                data << sgn->m_Min.fValue;
//                data << sgn->m_Max.fValue;
//                break;

//            default: break;
//            }

            data.clear();
        }
        cnt++;
    }
}

// MainDbCommonItem method define area

MainDbCommonItem::MainDbCommonItem(QVector<QVariant> &data,E_DbItemType itemType, MainDbCommonItem *parent)
{
    parentItem = parent;
    itemData = data;
    m_itemType = itemType;
}

MainDbCommonItem::~MainDbCommonItem()
{
    qDeleteAll(childItems);
}

MainDbCommonItem *MainDbCommonItem::child(int number)
{
    return childItems.value(number);
}

int MainDbCommonItem::childCount() const
{
    return childItems.count();
}

int MainDbCommonItem::childNumber() const
{
    if (parentItem)
        return parentItem->childItems.indexOf(const_cast<MainDbCommonItem*>(this));
    return 0;
}

int MainDbCommonItem::columnCount() const
{
    return itemData.size();
}

QVariant  MainDbCommonItem::data(int column) const
{
    return itemData.value(column);
}
bool MainDbCommonItem::insertChildren(int position, int count, int columns, E_DbItemType type)
{
    if (position < 0 || position > childItems.size())
        return false;

    for (int row = 0; row < count; ++row) {
        QVector<QVariant> data(columns);
        MainDbCommonItem *item = new MainDbCommonItem(data,type,this);
        childItems.insert(position, item);
    }
    return true;
}

bool MainDbCommonItem::insertColumns(int position, int columns)
{
    if (position < 0 || position > itemData.size())
        return false;
    for (int column = 0; column < columns; ++column)
        itemData.insert(position, QVariant());
    foreach (MainDbCommonItem *child, childItems)
        child->insertColumns(position, columns);
    return true;
}

MainDbCommonItem *MainDbCommonItem::parent()
{
    return parentItem;
}

bool MainDbCommonItem::removeChildren(int position, int count)
{
    if (position < 0 || position + count > childItems.size())
        return false;

    for (int row = 0; row < count; ++row)
        delete childItems.takeAt(position);

    return true;
}

bool MainDbCommonItem::removeColumns(int position, int columns)
{
    if (position < 0 || position + columns > itemData.size())
        return false;

    for (int column = 0; column < columns; ++column)
        itemData.removeAt(position);

    foreach (MainDbCommonItem *child, childItems)
        child->removeColumns(position, columns);

    return true;
}

bool MainDbCommonItem::setData(int column, const QVariant &value)
{
    if (column < 0 || column >= itemData.size())
        return false;

    itemData[column] = value;
    return true;
}
