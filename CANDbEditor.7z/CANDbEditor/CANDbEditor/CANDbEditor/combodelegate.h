#ifndef COMBODELEGATE_H
#define COMBODELEGATE_H
#include<maindbeditor.h>
#include <QItemDelegate>
#include <QModelIndex>
#include <QObject>
#include <QSize>
#include <QComboBox>
#include <QStringList>
class comboDelegate: public QItemDelegate
{
Q_OBJECT
public:
    comboDelegate(QObject *parent = 0);

    QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem &option,
                          const QModelIndex &index) const;

    void setEditorData(QWidget *editor, const QModelIndex &index) const;
    void setModelData(QWidget *editor, QAbstractItemModel *model,
                      const QModelIndex &index) const;

    void updateEditorGeometry(QWidget *editor,
        const QStyleOptionViewItem &option, const QModelIndex &index) const;
    QStringList listComBovalue;
};

#endif // COMBODELEGATE_H
